package gui;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import models.SalesEntry;
import models.SalesDatabase;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.UUID;

public class EditSalesEntryForm extends JFrame {
    private JComboBox<String> salesComboBox; 
    private JComboBox<String> itemComboBox;
    private JTextField dateField;
    private JTextField quantityField;
    private JButton addButton;
    private JButton deleteSalesButton; 
    private JFrame previousPage;

    public EditSalesEntryForm(JFrame previousPage) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);

        // Frame setup
        setTitle("Daily Sales Entry");
        setSize(600, 600); 
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Sales selection dropdown
        JLabel salesLabel = new JLabel("Select Sale:");
        salesLabel.setFont(new Font("Arial", Font.BOLD, 16));
        salesLabel.setForeground(Color.WHITE);
        salesLabel.setBounds(200, 20, 200, 30); 
        add(salesLabel);

        salesComboBox = new JComboBox<>();
        salesComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        salesComboBox.setBackground(new Color(105, 105, 105)); 
        salesComboBox.setForeground(Color.WHITE); 
        salesComboBox.setBounds(200, 60, 200, 30); 
        populateSalesComboBox(); 
        add(salesComboBox);

        // Item selection dropdown
        JLabel itemLabel = new JLabel("Select Item:");
        itemLabel.setFont(new Font("Arial", Font.BOLD, 16));
        itemLabel.setForeground(Color.WHITE);
        itemLabel.setBounds(200, 100, 200, 30); 
        add(itemLabel);

        itemComboBox = new JComboBox<>();
        itemComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        itemComboBox.setBackground(new Color(105, 105, 105)); 
        itemComboBox.setForeground(Color.WHITE); 
        itemComboBox.setBounds(200, 140, 200, 30);
        populateItemComboBox();
        add(itemComboBox);

        // Date field
        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        dateLabel.setFont(new Font("Arial", Font.BOLD, 16));
        dateLabel.setForeground(Color.WHITE);
        dateLabel.setBounds(200, 180, 200, 30);
        add(dateLabel);

        dateField = new JTextField(LocalDate.now().toString());
        dateField.setFont(new Font("Arial", Font.PLAIN, 14));
        dateField.setBackground(new Color(105, 105, 105)); 
        dateField.setForeground(Color.WHITE); 
        dateField.setBounds(200, 220, 200, 30);
        add(dateField);

        // Quantity field
        JLabel quantityLabel = new JLabel("Quantity Sold:");
        quantityLabel.setFont(new Font("Arial", Font.BOLD, 16));
        quantityLabel.setForeground(Color.WHITE);
        quantityLabel.setBounds(200, 260, 200, 30);
        add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setFont(new Font("Arial", Font.PLAIN, 14));
        quantityField.setBackground(new Color(105, 105, 105)); 
        quantityField.setForeground(Color.WHITE); 
        quantityField.setBounds(200, 300, 200, 30);
        add(quantityField);

        // Add Entry button
        addButton = new JButton("Edit Sale");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setBackground(new Color(11, 136, 255)); 
        addButton.setBounds(150, 360, 140, 40);
        addButton.addActionListener(e -> editSalesEntry());
        add(addButton);

        // Back button
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0)); 
        backButton.setBounds(310, 360, 140, 40);
        backButton.addActionListener(e -> goBack());
        add(backButton);

        // Delete Sales button
        deleteSalesButton = new JButton("Delete Sales");
        deleteSalesButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteSalesButton.setBackground(new Color(204, 0, 0)); 
        deleteSalesButton.setBounds(200, 420, 200, 40);
        deleteSalesButton.addActionListener(e -> deleteSelectedSale());
        add(deleteSalesButton);
    }

    // Populates the sales dropdown with tracker IDs from the file
    private void populateSalesComboBox() {
        salesComboBox.removeAllItems(); 

        try (BufferedReader reader = new BufferedReader(new FileReader("sales.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    String trackerID = parts[0];
                    salesComboBox.addItem(trackerID); 
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                "Error reading sales file: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }

        // Add ActionListener to auto-fill fields when a sale ID is selected
        salesComboBox.addActionListener(e -> autoFillFields());
    }
    
    // Auto-fills form fields with details of the selected sale
    private void autoFillFields() {
        String selectedSale = (String) salesComboBox.getSelectedItem();
        if (selectedSale == null || selectedSale.isEmpty()) {
            return; 
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("sales.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(selectedSale)) { 
                    itemComboBox.setSelectedItem(parts[1]); 
                    dateField.setText(parts[2]); 
                    quantityField.setText(parts[3]); 
                    break;
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                "Error reading sales file: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    // Populates the item dropdown with available item codes
    private void populateItemComboBox() {
        itemComboBox.removeAllItems(); 
        List<String[]> stockLevels = readStockLevels();
        for (String[] stock : stockLevels) {
            String itemCode = stock[0]; 
            itemComboBox.addItem(itemCode); 
        }
        if (itemComboBox.getItemCount() == 0) {
            JOptionPane.showMessageDialog(this, 
                "No items available in stock. Please update the stock levels first.", 
                "Warning", 
                JOptionPane.WARNING_MESSAGE);
        }
    }

    // Updates the selected sales entry and adjusts stock accordingly
    private void editSalesEntry() {
        String selectedSale = (String) salesComboBox.getSelectedItem();
        if (selectedSale == null || selectedSale.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No sale selected to edit.");
            return;
        }

        String itemCode = (String) itemComboBox.getSelectedItem();
        LocalDate date;
        int newQuantity;

        try {
            date = LocalDate.parse(dateField.getText());
            newQuantity = Integer.parseInt(quantityField.getText());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid date and quantity.");
            return;
        }

        List<String> updatedEntries = new ArrayList<>();
        boolean saleUpdated = false;
        int oldQuantity = 0; 

        try (BufferedReader reader = new BufferedReader(new FileReader("sales.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(selectedSale)) { 
                    oldQuantity = Integer.parseInt(parts[3]); 

                    // Update the sale details
                    updatedEntries.add(selectedSale + "," + itemCode + "," + date + "," + newQuantity);
                    saleUpdated = true;
                } else {
                    updatedEntries.add(line); 
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                "Error reading sales file: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Adjust stock levels based on the quantity difference
        if (saleUpdated) {
            int quantityDifference = newQuantity - oldQuantity;

            // Adjust stock: Deduct for positive difference, restock for negative difference
            if (!deductStockQuantity(itemCode, quantityDifference)) {
                return; 
            }

            // Write the updated sales back to the file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("sales.txt"))) {
                for (String entry : updatedEntries) {
                    writer.write(entry);
                    writer.newLine();
                }
                JOptionPane.showMessageDialog(this, "Sales entry updated successfully!");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                    "Error updating sales file: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update the selected sale.");
        }
    }

    // Deletes the selected sales entry
    private void deleteSelectedSale() {
        String selectedSale = (String) salesComboBox.getSelectedItem();
        if (selectedSale == null || selectedSale.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "No sale selected to delete.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Extract the tracker ID from the selected item
        String trackerID = selectedSale.split(" - ")[0]; 
        boolean success = deleteFromSalesFile(trackerID);

        if (success) {
            JOptionPane.showMessageDialog(this, "Sales entry deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            populateSalesComboBox(); 
        } else {
            JOptionPane.showMessageDialog(this, "No matching sales entry found to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Updateds sales in the file
    private boolean deleteFromSalesFile(String trackerID) {
        List<String> updatedEntries = new ArrayList<>();
        boolean found = false;

        try (BufferedReader reader = new BufferedReader(new FileReader("sales.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Check if the line starts with the tracker ID
                if (!line.startsWith(trackerID + ",")) {
                    updatedEntries.add(line); 
                } else {
                    found = true; 
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                "Error reading sales file: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (found) {
            // Write the updated entries back to the file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("sales.txt"))) {
                for (String entry : updatedEntries) {
                    writer.write(entry);
                    writer.newLine();
                }
                return true;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                    "Error updating sales file: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }

        return false; 
    }

    // Reads stock levels from a file
    private List<String[]> readStockLevels() {
        List<String[]> stockData = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("StockLevels.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stockData.add(line.split(",")); 
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, 
                "Error reading stock levels: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
        return stockData;
    }
  
    // Adjusts stock quantity based on sales changes
    private boolean deductStockQuantity(String itemCode, int quantitySold) {
        List<String[]> stockLevels = readStockLevels(); 
        boolean stockUpdated = false;

        // Update the stock quantity in memory
        for (String[] stock : stockLevels) {
            if (stock[0].equals(itemCode)) { 
                int currentStock = Integer.parseInt(stock[2]);
                if (currentStock < quantitySold) { 
                    JOptionPane.showMessageDialog(this,
                        "Insufficient stock! Available: " + currentStock,
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                    return false;
                }
                stock[2] = String.valueOf(currentStock - quantitySold); 
                stockUpdated = true;
                break;
            }
        }

        // Save updated stock levels back to the file
        if (stockUpdated) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("StockLevels.txt"))) {
                for (String[] stock : stockLevels) {
                    writer.write(String.join(",", stock));
                    writer.newLine();
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                    "Error updating stock levels: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }

        return stockUpdated;
    }
    // Returns to the previous page 
    private void goBack() {
        this.dispose();
        previousPage.setVisible(true);
    }
}
