package models;

// Extends the User class and provides Finance Manager-specific behavior
public class FinanceManager extends User {
    
    // Constructor
    public FinanceManager(String userId, String username, String password) {
        super(userId, username, password); // Call the User class constructor
    }

    // Implementation of the abstract method from User class
    // Defines the main menu behavior for a Finance Manager
    @Override
    public void accessMainMenu() {
        System.out.println("Accessing the main menu as Finance Manager");       
    }
}