package models;

// Extends the User class and provides SM-specific behavior
public class SalesManager extends User {
    
    // Constructor
    public SalesManager(String userId, String username, String password) {
        super(userId, username, password); // Call the User class constructor
    }

    // Implementation of the abstract method from User class
    // Defines the main menu behavior for a SM
    @Override
    public void accessMainMenu() {
        System.out.println("Accessing the main menu as Sales Manager");
    }
}